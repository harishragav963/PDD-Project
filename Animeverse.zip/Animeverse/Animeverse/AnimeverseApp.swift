//
//  AnimeverseApp.swift
//  Animeverse
//
//  Created by SAIL on 30/01/25.
//

import SwiftUI

@main
struct AnimeverseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
